<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Update Profile</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
</head>

<body class="light">
    
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Update Profile</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Update Profile</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Profile</strong> Update</h2>
                                            
                                        </div><hr>
                                        <div class="body">
                                            <form  onsubmit="return validateForm()" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Username" name="admin_name" value="<?php echo $admin_name;?>">
                                            </div>
                                            <div class="form-group">
                                                <input type="email" class="form-control" placeholder="Email" name="admin_email" readonly="" value="<?php echo $admin_email;?>">
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Mobile Number" name="admin_mobileno" value="<?php echo $admin_mobileno;?>">
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <div class="user-panel">
                                                        <div class="image">
                                                            <?php
                                                                if($admin_photo!="")
                                                                    { 
                                                                        ?>
                                                                        <img src="../images/<?php echo $admin_photo?>" id="preview_img" class="img-circle user-img-circle"
                                                                alt="User Image" />

                                                                        <?php 
                                                                    } 
                                                                    else 
                                                                    { 
                                                                        ?>
                                                                            <img src="../images/No-image-full.jpg" id="preview_img" height="75" width="75" />
                                                                        <?php 
                                                                    } 
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-9"><br><br>
                                                    <div class="file-field input-field">
                                                        <div class="btn">
                                                            <span>File</span>
                                                            <input type="file" id="image"  class="form-control" name="admin_photo" accept=" .png, .jpg, .jpeg" onchange="return fileValidation()" />
                                                        </div>
                                                        <div class="file-path-wrapper">
                                                            <input class="file-path validate" type="text" placeholder="Photo" value="<?php echo $admin_photo;?>">
                                                        </div>
                                                    </div>
                                                </div>

                                                    <script>
                                                        function fileValidation() {
                                                        var fileInput =
                                                        document.getElementById('image');

                                                        var filePath = fileInput.value;

                                                        // Allowing file type 
                                                        var allowedExtensions =
                                                        /(\.jpg|\.jpeg|\.png)$/i;

                                                        if (!allowedExtensions.exec(filePath)) {
                                                           alert('Invalid Image type');
                                                          fileInput.value = '';
                                                        return false;
                                                        }

                                                        }

                                                    </script>
                                            </div>
                                            <center><button class="btn btn-info btn-round" type="submit" name="update">Update Profile</button></center>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
    <script type="text/javascript">
        $(document).ready(function(){
            //Image file input change event
            $("#image").change(function(){
                readImageData(this);//Call image read and render function
            });
        });
        function readImageData(imgData){
            if (imgData.files && imgData.files[0]) {
                var readerObj = new FileReader();
                readerObj.onload = function (element) {
                    $('#preview_img').attr('src', element.target.result);
                }
                readerObj.readAsDataURL(imgData.files[0]);
            }
        }
    </script>

<?php
 
    if(isset($_POST['update']))
    {
        extract($_POST);
        $name=$_FILES['admin_photo']['name'];
        $size=$_FILES['admin_photo']['size'];
        $type=$_FILES['admin_photo']['type'];
        $temp=$_FILES['admin_photo']['tmp_name'];

        if($name)
            {
                $extension1 = strtolower(pathinfo($name,PATHINFO_EXTENSION));
                if($extension1=="jpg" || $extension1=="jpeg" || $extension1=="png")
                {
                    $desired_dir="../images/";               
                    $photo=uniqid().$name;
                    $extension = strtolower(pathinfo($photo,PATHINFO_EXTENSION));
                    
                     move_uploaded_file($temp,"$desired_dir/".$photo);
                      $save = "$desired_dir" . $photo; //This is the new file you saving
                      $file = "$desired_dir" . $photo; //This is the original file

                      list($width, $height) = getimagesize($file) ;

                      $modwidth = 200;

                      // $diff = $width / $modwidth;

                      // $modheight = $height / $diff;
                      $modheight = 200;
                       $tn = imagecreatetruecolor($modwidth, $modheight) ;
                        imagealphablending( $tn, false );
                        imagesavealpha( $tn, true );
                        if($extension=="jpg" || $extension=="jpeg" )
                        {

                            $image = imagecreatefromjpeg($file);
                             imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                            imagejpeg($tn, $save, 100); 
                        }
                        else if($extension=="png")
                        {

                            $image = imagecreatefrompng($file);
                            imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                            imagepng( $tn, $save, 9 );
                        }  
                }
                else
                {
                   echo '<script type="text/javascript">';
                   echo " alert('Please Upload Valid Image File')";
                   echo '<script>';
                }

            }
            else
            {
                $photo=$fetch['admin_photo'];
            }  

           $adsf="update tbl_admin set 
            admin_name='".$admin_name."',
            admin_email='".$admin_email."',
            admin_photo='".$photo."',
            admin_mobileno='".$admin_mobileno."'
            where admin_id='".$_SESSION['id']."'";  
      
            $update=mysqli_query($connect,$adsf) or die(mysqli_error($connect));
             
            if($update)
            {
               echo '<script type="text/javascript">';
               echo " alert('Profile Updated Successfully');";
               echo 'window.location.href = "update_profile.php";';
               echo '</script>';
      
            }
            else
            {
               echo '<script type="text/javascript">';
               echo "alert(' Not Update');";
               echo '</script>';
            }              
    }

?>