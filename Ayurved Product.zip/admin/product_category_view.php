<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Product Category</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Product Category</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Product Category Name</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <?php 
                    $view = mysqli_query($connect,"select * from tbl_product_category where fld_product_category_delete=0 order by fld_product_category_id desc") or die (mysqli_error($connect));
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <strong>Product</strong> Category Name</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="product_category_add.php" class="btn btn-primary" role="button">
                                        Add Product Category
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table
                                    class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Action</th>
                                            <th>Product Category Name</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $count = 1;

                                            while ($fetch=mysqli_fetch_array($view))
                                            {
                                                extract($fetch);

                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td>
                                                <a href="#" type="button" data-toggle="modal" data-target="#product_category<?php echo $fetch['fld_product_category_id'] ?>"  title="Edit Product Category Name"><i class="fas fa-edit" style="font-size: 20px" ></i> </a>

                                                <a href="product_category_delete.php?id=<?php echo $fetch['fld_product_category_id']; ?>" class="fas fa-trash-alt"  style="color: red;font-size: 20px;" onclick="return confirm('Are you sure you want to delete')"></a>
                                            </td>
                                            <td ><?php echo $fld_product_category_name; ?></td>
                                            <td><?php echo $fld_product_category_created_date; ?></td>
                                        </tr>

                                        <div class="modal fade bd-example-modal-lg" id="product_category<?php echo $fetch['fld_product_category_id'] ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Update Product Category Name
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form method="post" action="product_category_update.php?product_category_id=<?php echo $fetch['fld_product_category_id'] ?>">
                                                        <div class="modal-body">
                                                            <div class="form-group row">
                                                                <label class="col-sm-12 col-md-3 col-form-label">Product Category Name<span class="text-danger">*</span> : </label>
                                                                <div class="col-sm-12 col-md-9">
                                                                    <input class="form-control" type="text" name="product_category_name" id="product_category_name" placeholder="Enter Product Category Name" required="" value="<?php echo $fetch['fld_product_category_name'] ?>" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');" style="text-transform: capitalize;">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-info waves-effect" value="Update" name="update">Update</button>
                                                            <button type="button" class="btn btn-danger waves-effect"
                                                                data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
           
        </div>
    </section>

    <?php include'footer.php';?>
        
    <script src="assets/js/table.min.js"></script>
    <!-- Custom Js -->
    <script src="assets/js/admin.js"></script>
    <script src="assets/js/pages/tables/jquery-datatable.js"></script>