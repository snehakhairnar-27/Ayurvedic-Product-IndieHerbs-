<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Product Update</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <script src="assets/ckeditor/ckeditor.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
        function disc()
        {
            var f1=parseFloat(document.getElementById("product_price").value);
            var f2=parseFloat(document.getElementById("product_discount").value);
            var disc2=f2/100;
            var disc3=f1*disc2;
            var disc4=f1-disc3;
            document.getElementById("product_final_price").value=disc4;
        }
    </script>

</head>

<body class="light">
   
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Product</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Product Add</li>
                        </ul>

                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Product</strong> Update</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="product_view.php" class="btn btn-primary" role="button">
                                                        View Product
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <hr>
                                        <?php
                                            if(isset($_GET['id']));
                                            $query="select * from tbl_product where fld_product_id='".$_GET['id']."' group by fld_product_id order by fld_product_id desc";
                                            // $query="select p.*,c.*,pc.* from tbl_product p,tbl_subcategory c, tbl_product_category pc where p.fld_subcategory_id=c.fld_subcategory_id and
                                            //     p.fld_product_category_id=pc.fld_product_category_id and p.fld_product_id='".$_GET['id']."' group by p.fld_product_id order by p.fld_product_id desc";
                                            $row=mysqli_query($connect,$query) or die(mysqli_error($connect));
                                            $fetch=mysqli_fetch_array($row);
                                            extract($fetch);

                                        ?>                       
                                        <div class="body">
                                            <div class="row clearfix">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="card">
                                                        <div class="body">
                                                            <form method="post" class="form-horizontal" enctype="multipart/form-data">
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Category<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group default-select select2Style">
                                                                            <select class="form-control select2" data-placeholder="Select" name="product_category" id="product_category" required="">
                                                                                <option>Select Product Category</option>
                                                                                <?php
                                                                                    $query=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_delete=0 order by fld_product_category_name asc ");
                                                                                
                                                                                    while($row1=mysqli_fetch_assoc($query))
                                                                                    {
                                                                                        extract($row1);
                                                                                 ?>
                                                                                <option value="<?php echo $row1['fld_product_category_id'];?>" <?php if($row1['fld_product_category_id']==$fetch['fld_product_category_id']) {echo "selected";} ?>><?php echo $row1['fld_product_category_name'];?></option>

                                                                            <?php }?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <script type="text/javascript">
                                                                  $(document).ready(function(){
                                                                    $("select#product_category").change(function(){
                                                                          var u = $("#product_category option:selected").val();
                                                                          // alert(u);      
                                                                          $.ajax({
                                                                              type: "POST",
                                                                              url: "subcategory.php", 
                                                                              data: { product_category : u  } 
                                                                          }).done(function(data){
                                                                              $("#subcategory").html(data);
                                                                          });
                                                                      });
                                                                  });
                                                                </script>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Sub Category<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group default-select select2Style">
                                                                            <select class="form-control select2" data-placeholder="Select" name="subcategory" id="subcategory" required="">
                                                                                <option>Select Sub Category</option>
                                                                                <?php
                                                                                    $query=mysqli_query($connect,"select * from tbl_subcategory where fld_subcategory_delete=0 and fld_product_category_id='".$fetch['fld_product_category_id']."' order by fld_subcategory_name asc ");
                                                                                
                                                                                    while($row2=mysqli_fetch_assoc($query))
                                                                                    {
                                                                                        extract($row2);
                                                                                 ?>
                                                                                <option value="<?php echo $row2['fld_subcategory_id'];?>" <?php if($row2['fld_subcategory_id']==$fetch['fld_subcategory_id']) {echo "selected";} ?>><?php echo $row2['fld_subcategory_name'];?></option>
                                                                            <?php }?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Name<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_name" class="form-control" placeholder="Enter Product Name" required="" value="<?php echo $fetch['fld_product_name']?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Price<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_price" id="product_price" value="<?php echo $fetch['fld_product_price']?>" class="form-control" placeholder="Enter Product Price"  required="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" >
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Discount(%)<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" class="form-control" name="product_discount" id="product_discount" placeholder="Enter Product Discount" value="<?php echo $fetch['fld_product_discount']?>" required="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" onkeyup="disc()">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Final Price</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_final_price" id="product_final_price" value="<?php echo $fetch['fld_product_final_price']?>" class="form-control" readonly="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Colour</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_colour" class="form-control" placeholder="Enter Product Colour" value="<?php echo $fetch['fld_product_colour']?>" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Height(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_height" class="form-control" value="<?php echo $fetch['fld_product_height']?>" placeholder="Enter height" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Width(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_width" class="form-control" placeholder="Enter Width" value="" value="<?php echo $fetch['fld_product_width']?>" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Dimension(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_dimension" class="form-control" placeholder="Enter Dimension" value="<?php echo $fetch['fld_product_dimension']?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Weight</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_weight" class="form-control" placeholder="Enter Weight" value="<?php echo $fetch['fld_product_weight']?>" >
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Compatibility<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="product_compatibility" class="form-control" required=""><?php echo $fetch['fld_product_compatibility']?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label >Product Description<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="product_description" id="description" class="form-control" required=""><?php echo $fetch['fld_product_description']?></textarea>
                                                                            </div>
                                                                            <script>
                                                                                CKEDITOR.replace('description');
                                                                            </script>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-12 col-md-12 col-sm-10 col-xs-9">
                                                                        <center>
                                                                        <button type="submit" name="update" class="btn btn-primary m-t-15 waves-effect">Update</button></center>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
        <script language="javascript" type="text/javascript">
            $(function () {
                $("#product_photo").change(function () {
                    if (typeof (FileReader) != "undefined") {
                        var dvPreview = $("#dvPreview");
                        dvPreview.html("");
                        var regex = /^([a-zA-Z0-9()\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                        $($(this)[0].files).each(function () {
                            var file = $(this);
                            if (regex.test(file[0].name.toLowerCase())) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var img = $("<img/>");
                                    img.attr("style", "height:100px;width: 100px");
                                    img.attr("src", e.target.result);
                                    dvPreview.append(img);
                                }
                                reader.readAsDataURL(file[0]);
                            } else {
                                alert(file[0].name + " is not a valid image file.");
                                dvPreview.html("");
                                return false;
                            }
                        });
                    } else {
                        alert("This browser does not support HTML5 FileReader.");
                    }
                });
            });
        </script>  

    <?php   

        if (isset($_POST['update']))
         {
          extract($_POST);

            $up="update tbl_product set 
            fld_product_category_id='".$_POST['product_category']."',
            fld_subcategory_id='".$_POST['subcategory']."',        
            fld_product_name='".$product_name."',
            fld_product_price='".$product_price."',
            fld_product_discount='".$product_discount."',
            fld_product_final_price='".$product_final_price."',
            fld_product_colour='".$product_colour."',
            fld_product_height='".$product_height."',
            fld_product_width='".$product_width."',
            fld_product_dimension='".$product_dimension."',
            fld_product_weight='".$product_weight."',
            fld_product_compatibility='".$product_compatibility."',
            fld_product_description='".$product_description."'
            where fld_product_id='".$_GET['id']."'";
          
          $update=mysqli_query($connect,$up) or die(mysqli_error($connect));
            $back="product_view.php?id=".$_GET['id']."";

            if ($update) 
            {
              
              echo "<script>";
              echo "alert('Upadate Data Succesfully');";
              echo "window.location.href='".$back."'";
              echo "</script>";
            }
            else{

              echo "<script>";
              echo "alert('error in update');";
              echo "window.location.href='".$back."'";
              echo "</script>";
            }

            }

    ?>
     

