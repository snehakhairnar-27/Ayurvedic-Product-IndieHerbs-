/* Name			: Lang file for Css rules importer plugin
*  Creation		: 189/12/2010
*  Version		: 0.1
*  Author		: Tessier Ronan
*/

CKEDITOR.plugins.setLang( 'rulesimport', 'fr',
{
	rulesimport :
	{
		title		: 'Règles css',
		label		: 'Règles css',
		voiceLabel	: 'Règles css',
		toolbar		: 'Règles css',
		reset		: 'Aucune',
		groupLabel	: 'Règles'
	}
});
