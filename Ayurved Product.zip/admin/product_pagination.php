        
        <div class="row">
            <?php 
                
                include "../config.php";
                session_start();

                    $limit=8;
                    if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
                    $start_from = ($page-1) * $limit; 

                    $query=$_SESSION['query'];
                    $query .= " LIMIT $start_from, $limit";
                $record=mysqli_query($connect,$query) or die(mysqli_error($connect));
                
                while ($fetch=mysqli_fetch_array($record)) 
                {

                        extract($fetch);

                        $photo_view=mysqli_query($connect,"select * from tbl_product_photo where fld_product_id='".$fetch['fld_product_id']."' and fld_product_photo_delete=0 order by fld_product_photo_id desc");
                        $fetch_photo=mysqli_fetch_array($photo_view);
            
            ?>
            <div class="col-md-3 col-sm-6">
                <div class="product-grid">
                    <div class="product-image">
                        <a href="#">
                            <img class="pic-1" src="../images/product/<?php echo $fetch_photo['fld_product_photo'];?>" alt="">
                        </a>
                        <ul class="social">
                            <li><a href="product_photo_update.php?id=<?php echo $fetch['fld_product_id']; ?>" data-tip="Product Photo Update"><i class="fas fa-camera-retro"></i></a>
                            </li>
                            <li><a href="product_update.php?id=<?php echo $fetch['fld_product_id']; ?>" data-tip="Product Update"><i
                                        class="fas fa-edit"></i></a></li>
                            <li><a href="product_delete.php?id=<?php echo $fetch['fld_product_id']; ?>" data-tip="Product Delete" onclick="return confirm('Are you sure you want to delete')"><i
                                        class="fas fa-trash-alt"></i></a></li>
                        </ul>
                    </div>
                    <div class="product-content">
                        <h3 class="title"><?php echo $fetch['fld_product_name']; ?></h3>
                        <div class="price">&#8377; <?php echo $fetch['fld_product_final_price']; ?>
                            <span>&#8377; <?php echo $fetch['fld_product_price']; ?></span>
                        </div>
                        <a class="add-to-cart" href="product_details1.php?id=<?php echo $fetch['fld_product_id']; ?>" style="color: red;"><i class="fa fa-eye"></i> Product View</a>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>