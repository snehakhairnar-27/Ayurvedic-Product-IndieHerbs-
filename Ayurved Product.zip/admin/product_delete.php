<?php 
include "../config.php";
if(isset($_GET['id']))
{
  $del=mysqli_query($connect,"update tbl_product set fld_product_delete=1 where fld_product_id='".$_GET['id']."'") or die(mysqli_error($connect));

   $del1=mysqli_query($connect,"update tbl_product_photo set fld_product_photo_delete=1 where fld_product_id='".$_GET['id']."'") or die(mysqli_error($connect));

    $back="javascript:history.back()";
    if($del && $del1)
      {
        echo "<script>";
        echo "alert('Product Deleted');";
        echo "window.location.href='product_view.php';";
        echo "</script>";
      }
      else
      {
        echo "<script>";
        echo "alert('Error');";
        echo "window.location.href='product_view.php';";
        echo "</script>";
      }
}
?>