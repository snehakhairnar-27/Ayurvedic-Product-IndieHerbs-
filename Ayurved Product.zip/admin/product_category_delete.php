<?php 
include "../config.php";
if(isset($_GET['id']))
{
	$del=mysqli_query($connect,"update tbl_product_category set fld_product_category_delete=1 where fld_product_category_id='".$_GET['id']."'") or die(mysqli_error($connect));

		$back="javascript:history.back()";
		if($del)
			{
				echo "<script>";
				echo "alert('Product Category Name Deleted');";
				echo "window.location.href='product_category_view.php';";
				echo "</script>";
			}
			else
			{
				echo "<script>";
				echo "alert('Error');";
				echo "window.location.href='product_category_view.php';";
				echo "</script>";
			}
}
?>