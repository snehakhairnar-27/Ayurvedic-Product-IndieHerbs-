<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Home Slider Update</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <style>
            .preview_box{clear: both; padding: 5px; margin-top: 10px; text-align:left;}
            .preview_box img{max-width: 100px; max-height: 100px;}
        </style>
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Home Slider</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Add Home Slider</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Home</strong> Slider Add</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="home_slider_view.php" class="btn btn-primary" role="button">
                                                        View Home Slider
                                                    </a>
                                                </li>
                                            </ul>
                                        </div><hr>
                                        <?php 
                                            $query="select * from tbl_home_slider where fld_slider_id='".$_GET['id']."' and fld_slider_delete=0 ";
                                            $view=mysqli_query($connect,$query);
                                            $fetch=mysqli_fetch_array($view);
                                            extract($fetch);
                                        ?>
                                        <div class="body">
                                            <form method="POST" class="form-horizontal form-bordered" onsubmit="return validateForm()" enctype="multipart/form-data">
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Slider Name<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="slider_name" id="slider_name" class="form-control" value="<?php echo $fetch['fld_slider_name']?>" placeholder="Enter slider name" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Photo<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <div class="preview_box">
                                                                <?php
                                                                        if ($fetch['fld_slider_image']=="") 
                                                                        {
                                                                    ?>

                                                                <img src="../images/No-image-full.jpg" alt="" style="width: 100px; height: 100px" id="dvPreview">
                                                                <?php
                                                                        }
                                                                        else
                                                                        {
                                                                    ?>
                                                                <img src="../images/slider/<?php echo $fetch['fld_slider_image']; ?>" alt="" style="width: 100px; height: 100px" id="dvPreview">
                                                                <?php
                                                                    }
                                                                ?>

                                                                </div>
                                                                <input class="form-control" name="fld_slider_image" id="image" type="file" multiple oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');" accept=" .jpg , .jpeg , .png ">
                                                                <script>
                                                                    function fileValidation1() {
                                                                        var fileInput =
                                                                            document.getElementById('fld_slider_image');

                                                                        var filePath = fileInput.value;

                                                                        // Allowing file type 
                                                                        var allowedExtensions =
                                                                            /(\.jpg|\.jpeg|\.png)$/i;

                                                                        if (!allowedExtensions.exec(filePath)) {
                                                                            alert('Invalid Image type');
                                                                            fileInput.value = '';
                                                                            return false;
                                                                        }

                                                                    }
                                                                </script>
                                                            </div>
                                                        </div>
                                                        <span style="color: red;" >Please upload image png, jpg, jpeg Format in Width 1519 X Height 500 Size. You can select multiple images.</span> 
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label >Slider Description</label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <textarea rows="3" name="description" id="description" class="form-control no-resize" placeholder="Please type slider description"><?php echo $fetch['fld_slider_description']?></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <center>
                                                        <button type="submit" name="update" class="btn btn-primary m-t-15 waves-effect">Update</button></center>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
    <script type="text/javascript">
        $(document).ready(function(){
            //Image file input change event
            $("#image").change(function(){
                readImageData(this);//Call image read and render function
            });
        });
        function readImageData(imgData){
            if (imgData.files && imgData.files[0]) {
                var readerObj = new FileReader();
                readerObj.onload = function (element) {
                    $('#dvPreview').attr('src', element.target.result);
                }
                readerObj.readAsDataURL(imgData.files[0]);
            }
        }
    </script>

<?php 

    if(isset($_POST['update']))
    {

        extract($_POST);

            $name=$_FILES['fld_slider_image']['name'];
            $type=$_FILES['fld_slider_image']['type'];
            $size=$_FILES['fld_slider_image']['size'];
            $temp=$_FILES['fld_slider_image']['tmp_name'];
            if($name)
            {

                $extension1 = strtolower(pathinfo($name,PATHINFO_EXTENSION));

                if($extension1=="jpg" || $extension1=="jpeg" || $extension1=="png")
                {
                    $desired_dir="../images/slider/";  
                    unlink($desired_dir.$fetch['fld_slider_image']);             
                    $fld_slider_image=uniqid().$name;
                    $extension = strtolower(pathinfo($fld_slider_image,PATHINFO_EXTENSION));
                
                    move_uploaded_file($temp,"$desired_dir".$fld_slider_image);
                    
                    $save = "$desired_dir" . $fld_slider_image; //This is the new file you saving
                    $file = "$desired_dir" . $fld_slider_image; //This is the original file

                    list($width, $height) = getimagesize($file) ;

                    $modwidth = 1519;
                    $modheight = 500;
                    $tn = imagecreatetruecolor($modwidth, $modheight) ;
                    imagealphablending( $tn, false );
                    imagesavealpha( $tn, true );
                    if($extension=="jpg" || $extension=="jpeg" )
                    {

                        $image = imagecreatefromjpeg($file);
                        imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                        imagejpeg($tn, $save, 100); 
                    }
                    else if($extension=="png")
                    {

                        $image = imagecreatefrompng($file);
                        imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                        imagepng( $tn, $save, 9 );
                    }
                }
                else
                {
                   echo '<script type="text/javascript">';
                   echo " alert('Please Upload Valid Image File');";
                   // echo 'window.location.href = "index.php";';
                   echo '<script>';
                
                }
            }
            else
            {
                $fld_slider_image=$fetch['fld_slider_image'];
            }  

            $adsf="update tbl_home_slider set 
            fld_slider_name='".$slider_name."',
            fld_slider_image='".$fld_slider_image."',
            fld_slider_description='".$description."'
            where fld_slider_id='".$_GET['id']."'";         

            $update=mysqli_query($connect, $adsf) or die(mysqli_error($connect));

            $back="home_slider_update.php?id='".$_GET['id']."'";
            if($update)
            {
                echo "<script>";
                echo "alert('Slider Updated');";
                echo "window.location.href='home_slider_view.php';";
                echo "</script>";
            }
            else
            {
                echo "<script>";
                echo "alert('Error');";
                // echo "window.location.href='".$back."'";
                echo "</script>";
            }
        
    }
?>