<?php
include "../config.php";

$delete1=mysqli_query($connect,"update tbl_offer_banner set fld_offer_banner_delete=1 where fld_offer_banner_id='".$_GET['id']."'") or die(mysqli_error($connect));
        

$back="javascript:history.back()";
  if($delete1)

          {
            echo '<script type="text/javascript">';
            echo "alert('Banner Deleted');";
            echo 'window.location.href = "offer_banner_view.php";';
            echo "</script>";

          }
         else
         {
            echo '<script type="text/javascript">';
            echo "alert('Banner Not Delete');";
            echo 'window.location.href = "offer_banner_view.php";';
            echo "</script>";
             
             }

             ?>