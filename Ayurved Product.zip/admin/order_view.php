<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - User Order View</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <style>
            .preview_box{clear: both; padding: 5px; margin-top: 10px; text-align:left;}
            .preview_box img{max-width: 100px; max-height: 100px;}
        </style>
</head>

<body class="light">
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">User Order</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">User Order</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <?php 
                    $view = mysqli_query($connect,"select p.*,c.* from tbl_order_add p,tbl_user c where p.fld_user_id=c.fld_user_id and p.fld_order_delete=0 order by p.fld_order_id asc") or die (mysqli_error($connect));
                ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                <strong>User</strong> Order</h2>
                            
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table
                                    class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Action</th>
                                            <th>Order Status</th>
                                            <th>User Name</th>
                                            <th>User Number</th>
                                            <th>Order Price</th>
                                            <th>Invoice Number</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $count = 1;

                                            while ($fetch=mysqli_fetch_array($view))
                                            {
                                                extract($fetch);

                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td>
                                                <a href="#" type="button" data-toggle="modal" data-target="#order<?php echo $fetch['fld_order_id'] ?>"  title="Update Tracking Order"><i class="fas fa-truck" style="font-size: 20px" ></i> </a>
                                                
                                                <a href="order_delete.php?oid=<?php echo $fetch['fld_order_id']; ?>" class="fas fa-trash-alt"  style="color: red;font-size: 20px;" onclick="return confirm('Are you sure you want to delete order')"></a>
                                            </td>
                                             <td ><?php echo $fld_order_status; ?></td>
                                            <td ><?php echo $fld_user_name; ?></td>
                                             <td ><?php echo $fld_order_mobile; ?></td>
                                            <td >Rs. <?php echo $fld_order_total_bill_amt; ?></td>
                                             <td ><?php echo $fld_invoice_no; ?></td>
                                            <td><?php echo $fld_order_created_date; ?></td>
                                        </tr>

                                        <div class="modal fade bd-example-modal-lg" id="order<?php echo $fetch['fld_order_id'] ?>" tabindex="-1" role="dialog"
                                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Update Tracking Order
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form method="post" action="track_update.php?tid=<?php echo $fetch['fld_order_id'] ?>">
                                                        <div class="modal-body">
                                                            <div class="row clearfix">
                                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                                    <div class="row clearfix">
                                                                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-5 form-control-label">
                                                                            <label>Order Status</label>
                                                                        </div>
                                                                        <div class="col-lg-9 col-md-9 col-sm-8 col-xs-7">
                                                                            <div class="form-group default-select select2Style">
                                                                                <select class="form-control select2" data-placeholder="Select" name="status" id="status">
                                                                                    <option value=""><?php echo $fetch['fld_order_status'];?></option>
                                                                                    <option value="Confirm Order">Confirm Order</option>
                                                                                    <option value="Processing Order">Processing Order</option>
                                                                                    <option value="Product Disoatched">Product Disoatched</option>
                                                                                    <option value="Product Delivered">Product Delivered</option>
                                                                                
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-info waves-effect" value="Update" name="update">Update</button>
                                                            <button type="button" class="btn btn-danger waves-effect"
                                                                data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
           
        </div>
    </section>

    <?php include'footer.php';?>
        
    <script src="assets/js/table.min.js"></script>
    <!-- Custom Js -->
    <script src="assets/js/admin.js"></script>
    <script src="assets/js/pages/tables/jquery-datatable.js"></script>