<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Product Add</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <script src="assets/ckeditor/ckeditor.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script>
            function disc()
            {
                var f1=parseFloat(document.getElementById("product_price").value);
                var f2=parseFloat(document.getElementById("product_discount").value);
                var disc2=f2/100;
                var disc3=f1*disc2;
                var disc4=f1-disc3;
                document.getElementById("product_final_price").value=disc4;
            }
        </script>

</head>

<body class="light">
    
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Product</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Product Add</li>
                        </ul>

                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Product</strong> Add</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="product_view.php" class="btn btn-primary" role="button">
                                                        View Product
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <hr>
                                        <div class="body">
                                            <div class="row clearfix">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="card">
                                                        <div class="body">
                                                            <form method="post" class="form-horizontal" enctype="multipart/form-data">
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Name<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_name" class="form-control" placeholder="Enter Product Name" required="" value="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Photo<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                         
                                                                            <div class="row">
                                                                                <div id="dvPreview"></div>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <div class="form-line">
                                                                                    <input class="form-control" name="files[]" id="product_photo" type="file" multiple required="" accept=" .jpg , .jpeg , .png ">
                                                                                    <span style="color: red;" >Please upload image png, jpg, jpeg Format. You can select multiple images.</span> 
                                                                                </div>
                                                                            </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Category<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group default-select select2Style">
                                                                            <select class="form-control select2" data-placeholder="Select" name="product_category" id="product_category" required="">
                                                                                <option>Select Product Category</option>
                                                                                <?php
                                                                                    $query=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_delete=0 order by fld_product_category_name asc ");
                                                                                
                                                                                    while($row=mysqli_fetch_assoc($query))
                                                                                    {
                                                                                        extract($row);
                                                                                 ?>
                                                                                <option value="<?php echo $row['fld_product_category_id'];?>"><?php echo $row['fld_product_category_name'];?></option>
                                                                            <?php }?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <script type="text/javascript">
                                                                  $(document).ready(function(){
                                                                    $("select#product_category").change(function(){
                                                                          var u = $("#product_category option:selected").val();
                                                                          // alert(u);      
                                                                          $.ajax({
                                                                              type: "POST",
                                                                              url: "subcategory.php", 
                                                                              data: { product_category : u  } 
                                                                          }).done(function(data){
                                                                              $("#subcategory").html(data);
                                                                          });
                                                                      });
                                                                  });
                                                                </script>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Sub Category<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group default-select select2Style">
                                                                            <select class="form-control select2" data-placeholder="Select" name="subcategory" id="subcategory" required="">
                                                                                <option>Select Sub Category</option>
                                                                                
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Price<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_price" id="product_price" class="form-control" placeholder="Enter Product Price"  required="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" >
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Discount(%)<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" class="form-control" name="product_discount" id="product_discount" placeholder="Enter Product Discount"  required="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" onkeyup="disc()">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Final Price</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_final_price" id="product_final_price" class="form-control" readonly="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Colour</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_colour" class="form-control" placeholder="Enter Product Colour" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Height(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_height" class="form-control" placeholder="Enter height" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Width(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_width" class="form-control" placeholder="Enter Width" value="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Dimension(cm)</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_dimension" class="form-control" placeholder="Enter Dimension" value="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Weight</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="product_weight" class="form-control" placeholder="Enter Weight" >
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Product Compatibility<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="product_compatibility" class="form-control" required=""></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label >Product Description<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="product_description" id="description" class="form-control" required=""></textarea>
                                                                            </div>
                                                                            <script>
                                                                                CKEDITOR.replace('description');
                                                                            </script>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-12 col-md-12 col-sm-10 col-xs-9">
                                                                        <center>
                                                                        <button type="submit" name="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button></center>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
        <script language="javascript" type="text/javascript">
            $(function () {
                $("#product_photo").change(function () {
                    if (typeof (FileReader) != "undefined") {
                        var dvPreview = $("#dvPreview");
                        dvPreview.html("");
                        var regex = /^([a-zA-Z0-9()\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                        $($(this)[0].files).each(function () {
                            var file = $(this);
                            if (regex.test(file[0].name.toLowerCase())) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var img = $("<img/>");
                                    img.attr("style", "height:100px;width: 100px");
                                    img.attr("src", e.target.result);
                                    dvPreview.append(img);
                                }
                                reader.readAsDataURL(file[0]);
                            } else {
                                alert(file[0].name + " is not a valid image file.");
                                dvPreview.html("");
                                return false;
                            }
                        });
                    } else {
                        alert("This browser does not support HTML5 FileReader.");
                    }
                });
            });
        </script>  

    <?php   
        if(isset($_POST['submit']))
        {
            extract($_POST); 

             $ins="insert into tbl_product(fld_product_category_id,fld_subcategory_id,fld_product_name,fld_product_price,fld_product_discount,fld_product_final_price,fld_product_colour,fld_product_height,fld_product_width,fld_product_dimension,fld_product_weight,fld_product_compatibility,fld_product_description)values('".$_POST['product_category']."','".$_POST['subcategory']."','$product_name','$product_price','$product_discount','$product_final_price','$product_colour','$product_height','$product_width','$product_dimension','$product_weight','$product_compatibility','$product_description')";

            // echo "<br>";
                
                $add=mysqli_query($connect,$ins) or die(mysqli_error($connect));

                $sel=mysqli_query($connect,"select * from tbl_product where  fld_product_name='".$product_name."' order by fld_product_id desc limit 1");

                $fetch=mysqli_fetch_array($sel);

                $product_id=$fetch['fld_product_id'];
              // echo "<br>";

                if(isset($_FILES['files']))
                {   
                    
                    foreach($_FILES['files']['tmp_name'] as $key => $tmp_name )
                    {
                        $file_name = $key.$_FILES['files']['name'][$key];
                        $file_size =$_FILES['files']['size'][$key];
                        $file_tmp =$_FILES['files']['tmp_name'][$key];
                        $file_type=$_FILES['files']['type'][$key];  

                        $slider_image=uniqid().$file_name;
                       
                        $extension = strtolower(pathinfo($slider_image,PATHINFO_EXTENSION));

                       if($extension=="jpg" || $extension=="jpeg" || $extension=="png")
                        {  
                         
                            $query="INSERT into tbl_product_photo(fld_product_id, fld_product_photo) VALUES('$product_id','$slider_image') ";
                         // echo "<br>";

                            $desired_dir="../images/product/";
                            move_uploaded_file($file_tmp,"$desired_dir/".$slider_image);

                            $add2=mysqli_query($connect,$query); 

                            $save = "$desired_dir" . $slider_image; //This is the new file you saving
                            $file = "$desired_dir" . $slider_image; //This is the original file

                            list($width, $height) = getimagesize($file) ;

                            $modwidth = 500;                  
                            $modheight = 500;
                            $tn = imagecreatetruecolor($modwidth, $modheight) ;
                            imagealphablending( $tn, false );
                            imagesavealpha( $tn, true );
                            if($extension=="jpg" || $extension=="jpeg" )
                            {

                                $image = imagecreatefromjpeg($file);
                                 imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagejpeg($tn, $save, 100); 
                            }
                            else if($extension=="png")
                            {

                                $image = imagecreatefrompng($file);
                                imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagepng( $tn, $save, 9 );
                            }   
                        }
                    }
                }

                if($add && $add2)
                {
                    echo "<script>";
                    echo "alert('Product Added Successfully');";
                    echo "window.location.href='product_view.php';";
                    echo "</script>";
                }
                else
                {
                    echo "<script>";
                    echo "alert('Oops Error Occured');";
                    echo "window.location.href='product_add.php';";
                    echo "</script>";
                }                   
        }
    ?>      

