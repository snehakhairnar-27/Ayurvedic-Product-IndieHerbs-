<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Product Category Add</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>


        <?php 
            if (isset($_POST['submit'])) 
            {                    
                extract($_POST);
                $status=array();

                $total_title = count($_POST['product_category']);

                for($i=0;$i<$total_title;$i++)
                {
                    if(($_POST['product_category'][$i]!=""))
                    {
                        $prod1=$_POST['product_category'][$i];
                        $title=ucwords(strtolower($prod1));

                        $pd=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_name = '".$title."'");
                        if(mysqli_num_rows($pd)>0)
                        {
                            echo "<script>";
                            // echo "alert('Title Is Already Exists');";
                            // echo "window.location.href='.php';";
                            echo "</script>";
                        }
                     
                        else
                        {

                          $query = "insert into tbl_product_category(fld_product_category_name) VALUES ('".$title."')" ;
                          $result = mysqli_query($connect,$query)or die(mysqli_error($connect));

                          if(!empty($result)) 

                              {
                                  $status[]=1;                 
                              }
                              else
                              {
                                  echo "<script>";
                                   echo "alert('Product category not added successfully');";
                                  echo "window.location.href='product_category_view.php';";
                                  echo "</script>";
                              }
                        }
                    }
                }  

                if((isset($status)) &&(in_array('1', $status)))  
                {
                  echo "<script>";
                  echo "alert('Product category added successfully');";
                  echo "window.location.href='product_category_view.php';";
                  echo "</script>";
                }              
            }             
        ?>
    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Product Category</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Add Product Category</li>
                        </ul>

                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Product</strong> Category Name</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="product_category_view.php" class="btn btn-primary" role="button">
                                                        View Product Category
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="body">
                                            <form method="POST" class="form-horizontal form-bordered" onsubmit="return validateForm()" enctype="multipart/form-data">
                                                
                                                <div class="row clearfix">  
                                                    <div class="body table-responsive">
                                                        <table class="table" id="pd">
                                                            <tbody>
                                                                <tr class="tr-header">
                                                                    <th><a href="javascript:void(0);" id="addMore" title="Add More"><span class="fa fa-plus text-success"></span></a></th>
                                                                    <th>Product Category Name<span class="text-danger">*</span> : </th>
                                                                </tr>
                                                                <tr>
                                                                    <td><a href='javascript:void(0);' class='remove'><span class='fa fa-minus text-danger'></span></a></td>
                                                                    <td><input type="text" name="product_category[]" id="product_category" placeholder="Enter Product Category Name" class="form-control" required=""></td>
                                                                </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <center>
                                                        <button type="submit" name="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button></center>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
        <script>
            $(function(){
            $('#addMore').on('click', function() {
                      var data = $("#pd tr:eq(1)").clone(true).appendTo("#pd");
                      data.find("input").val('');
             });
             $(document).on('click', '.remove', function() {
                 var trIndex = $(this).closest("tr").index();
                    if(trIndex>1) {
                     $(this).closest("tr").remove();
                   } else {
                     alert("Sorry!! Can't remove first row!");
                   }
              });
            });      
        </script>


        <?php 
            if (isset($_POST['submit'])) 
            {                    
                extract($_POST);
                $status=array();

                $total_title = count($_POST['product_category']);

                for($i=0;$i<$total_title;$i++)
                {
                    if(($_POST['product_category'][$i]!=""))
                    {
                        $prod1=$_POST['product_category'][$i];
                        $title=ucwords(strtolower($prod1));

                        $pd=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_name = '".$title."'");
                        if(mysqli_num_rows($pd)>0)
                        {
                            echo "<script>";
                            // echo "alert('Title Is Already Exists');";
                            // echo "window.location.href='.php';";
                            echo "</script>";
                        }
                     
                        else
                        {

                          $query = "insert into tbl_product_category(fld_product_category_name) VALUES ('".$title."')" ;
                          $result = mysqli_query($connect,$query)or die(mysqli_error($connect));

                          if(!empty($result)) 

                              {
                                  $status[]=1;                 
                              }
                              else
                              {
                                  echo "<script>";
                                   echo "alert('Product Category not added successfully');";
                                  echo "window.location.href='product_category_view.php';";
                                  echo "</script>";
                              }
                        }
                    }
                }  

                if((isset($status)) &&(in_array('1', $status)))  
                {
                  echo "<script>";
                  echo "alert('Product Category added successfully');";
                  echo "window.location.href='product_category_view.php';";
                  echo "</script>";
                }              
            }             
        ?>