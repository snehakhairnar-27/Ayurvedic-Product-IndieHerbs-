<?php
include "../config.php";

$delete1=mysqli_query($connect,"update tbl_home_slider set fld_slider_delete=1 where fld_slider_id='".$_GET['id']."'") or die(mysqli_error($connect));      

$back="javascript:history.back()";
  if($delete1)

    {
      echo '<script type="text/javascript">';
      echo "alert('Slider Deleted');";
      echo 'window.location.href = "home_slider_view.php";';
      echo "</script>";

    }
   else
   {
      echo '<script type="text/javascript">';
      echo "alert('Slider Not Delete');";
      echo 'window.location.href = "home_slider_view.php";';
      echo "</script>";
       
       }

?>