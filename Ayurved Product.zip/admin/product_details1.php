<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Product View</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <script src="assets/ckeditor/ckeditor.js"></script>
    
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Product Details</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="product_view.php">Product</a>
                            </li>
                            <li class="breadcrumb-item active">Product Details</li>
                        </ul>
                    </div>
                </div>
            </div>

            <?php 
                $count=1; 
               if(isset($_GET['id']));
               {
                    $query="select p.*,c.*,pc.* from tbl_product p,tbl_subcategory c, tbl_product_category pc where p.fld_subcategory_id=c.fld_subcategory_id and
                        p.fld_product_category_id=pc.fld_product_category_id and p.fld_product_id='".$_GET['id']."' group by p.fld_product_id order by p.fld_product_id desc";
                    $row=mysqli_query($connect,$query) or die(mysqli_error($connect));
                    $fetch=mysqli_fetch_array($row);
                    extract($fetch);

                    $photo_view=mysqli_query($connect,"select * from tbl_product_photo where fld_product_id='".$fetch['fld_product_id']."' order by fld_product_photo_id desc ");
            ?>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="body">
                            <div class="block-header">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <ul class="breadcrumb breadcrumb-style ">
                                            <li class="bcrumb-1">
                                                <a href="dashboard.php">Home</a>
                                            </li>
                                            <li class="bcrumb-1">
                                                <a href="product_view.php">Product</a>
                                            </li>
                                            <li class="bcrumb-3">
                                                <a onClick="return false;">Product Details</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body ">
                                <div class="product-store">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                            <h4 class="product-title mb-2"><?php echo $fetch['fld_product_name'];?></h4>
                                            <h2 class="product-price display">&#8377; <?php echo $fetch['fld_product_final_price'];?>&nbsp; &#8377;<del><?php echo $fld_product_price; ?></del></h2>
                                            <div class="product-gallery">
                                                <div class="product-gallery-thumbnails">
                                                    <ol class="thumbnails-list list-unstyled">
                                                        <?php while($fetch_photo=mysqli_fetch_array($photo_view)) { ?>
                                                        <li><img src="../images/product/<?php echo $fetch_photo['fld_product_photo'];?>" alt=""></li>
                                                        <?php } ?>
                                                    </ol>
                                                </div>
                                                <div class="product-gallery-featured">
                                                    <?php $abc=mysqli_query($connect,"select * from tbl_product_photo where fld_product_id='".$fetch['fld_product_id']."' order by fld_product_photo_id desc ") or die(mysqli_error($connect)) ;
                                                        $xyz=mysqli_fetch_assoc($abc);
                                                       
                                                     ?>
                                                    <img src="../images/product/<?php echo $xyz['fld_product_photo'];?>" alt="">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                            <div class="card">
                                                <div class="body">
                                                    <!-- Nav tabs -->
                                                    <ul class="nav nav-tabs tab-nav-right" role="tablist">
                                                        <li role="presentation">
                                                            <a href="#profile" data-toggle="tab" class="active show">Description</a>
                                                        </li>
                                                        <li role="presentation">
                                                            <a href="#home" data-toggle="tab">Features</a>
                                                        </li>
                                                        <li role="presentation">
                                                            <a href="#messages" data-toggle="tab">Compatibility</a>
                                                        </li>
                                                    </ul>
                                                    <!-- Tab panes -->
                                                    <div class="tab-content">
                                                        
                                                        <div role="tabpanel" class="tab-pane fade in active show" id="profile">
                                                            <div class="product-description">
                                                                <h2 class="mb-5">Description</h2>
                                                                <?php echo $fetch['fld_product_description'];?>
                                                            </div>
                                                        </div>
                                                        <div role="tabpanel" class="tab-pane fade" id="home">
                                                            <div class="product-description">
                                                                <h2 class="mb-5">Features</h2>
                                                                <dl class="row mb-5">
                                                                    <dt class="col-sm-3">Brand</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_subcategory_name'];?></dd>
                                                                    <dt class="col-sm-3">Dimensions</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_product_dimension'];?></dd>
                                                                    <dt class="col-sm-3">Weight</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_product_weight'];?> Kgs </dd>
                                                                    <dt class="col-sm-3">Height</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_product_height'];?> Cm</dd>
                                                                    <dt class="col-sm-3">Width</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_product_width'];?> Cm</dd>
                                                                    <dt class="col-sm-3">Colour</dt>
                                                                    <dd class="col-sm-9"><?php echo $fetch['fld_product_colour'];?></dd>
                                                                </dl>
                                                            </div>
                                                        </div>
                                                        <div role="tabpanel" class="tab-pane fade" id="messages">
                                                            <b>Compatability</b>
                                                            <div class="product-faq mb-5">
                                                                <p class="text-muted"><?php echo $fetch['fld_product_compatibility'];?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php }?>
        </div>
    </section>

    <?php include'footer.php';?>

    <script src="assets/js/pages/ecommerce/product-detail.js"></script>

     

