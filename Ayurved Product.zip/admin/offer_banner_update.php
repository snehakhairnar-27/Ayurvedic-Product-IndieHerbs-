<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Offer Banner Update</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <style>
            .preview_box{clear: both; padding: 5px; margin-top: 10px; text-align:left;}
            .preview_box img{max-width: 100px; max-height: 100px;}
        </style>
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Offer Banner</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Add Banner</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Banner</strong> Add</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="offer_banner_view.php" class="btn btn-primary" role="button">
                                                        View Banner
                                                    </a>
                                                </li>
                                            </ul>
                                        </div><hr>
                                        <?php 
                                            $query="select * from tbl_offer_banner where fld_offer_banner_delete=0 and  fld_offer_banner_id='".$_GET['id']."'";
                                            $view=mysqli_query($connect,$query);
                                            $fetch=mysqli_fetch_array($view);
                                            extract($fetch);
                                        ?>
                                        <div class="body">
                                            <form class="form-horizontal" method="post" enctype="multipart/form-data">
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Offer Banner Name<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="offer_banner_name" id="offer_banner_name" class="form-control" value="<?php echo $fetch['fld_offer_banner_name']?>" placeholder="Enter offer_banner name" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Photo<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="row">
                                                            <div id="dvPreview"></div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <div class="preview_box">
                                                                <?php
                                                                        if ($fetch['fld_offer_banner_image']=="") 
                                                                        {
                                                                    ?>

                                                                <img src="../images/No-image-full.jpg" alt="" style="width: 100px; height: 100px" id="dvPreview">
                                                                <?php
                                                                        }
                                                                        else
                                                                        {
                                                                    ?>
                                                                <img src="../images/banner/<?php echo $fetch['fld_offer_banner_image']; ?>" alt="" style="width: 100px; height: 100px" id="dvPreview">
                                                                <?php
                                                                    }
                                                                ?>

                                                                </div>
                                                                <input class="form-control" name="fld_offer_banner_image" id="fld_offer_banner_image" type="file" accept=" .jpg , .jpeg , .png " onchange="return fileValidation1()">
                                                                <script>
                                                                    function fileValidation1() {
                                                                        var fileInput =
                                                                            document.getElementById('fld_offer_banner_image');

                                                                        var filePath = fileInput.value;

                                                                        // Allowing file type 
                                                                        var allowedExtensions =
                                                                            /(\.jpg|\.jpeg|\.png)$/i;

                                                                        if (!allowedExtensions.exec(filePath)) {
                                                                            alert('Invalid Image type');
                                                                            fileInput.value = '';
                                                                            return false;
                                                                        }

                                                                    }
                                                                </script>
                                                            </div>
                                                        </div>
                                                        <span style="color: red;" >Please upload image png, jpg, jpeg Format in Width 580 X Height 224 Size. You can select multiple images.</span> 
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label >Banner Description</label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <textarea rows="3" name="description" id="description" class="form-control no-resize" placeholder="Please type offer_banner description"><?php echo $fetch['fld_offer_banner_description']?></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <center>
                                                        <button type="submit" name="update" class="btn btn-primary m-t-15 waves-effect">Update</button></center>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
    <script type="text/javascript">
            $(document).ready(function() {
                //Image file input change event
                $("#fld_offer_banner_image").change(function() {
                    readImageData(this); //Call image read and render function
                });
            });

            function readImageData(imgData) {
                if (imgData.files && imgData.files[0]) {
                    var readerObj = new FileReader();

                    readerObj.onload = function(element) {
                        $('#dvPreview').attr('src', element.target.result);
                    }

                    readerObj.readAsDataURL(imgData.files[0]);
                }
            }
        </script>

<?php 

    if(isset($_POST['update']))
    {

        extract($_POST);

            $name1=$_FILES['fld_offer_banner_image']['name'];
            $type=$_FILES['fld_offer_banner_image']['type'];
            $size=$_FILES['fld_offer_banner_image']['size'];
            $temp=$_FILES['fld_offer_banner_image']['tmp_name'];
              if($name1)
              {  
                $upload= "../images/banner/";
                unlink($upload.$fld_offer_banner_image);
                $imgExt=strtolower(pathinfo($name1, PATHINFO_EXTENSION));
                $valid_ext= array('jpg','png','jpeg' );
                $photo= rand(1000,1000000).".".$imgExt;
                move_uploaded_file($temp,$upload.$photo);
              }
               else
              {
                $photo=$name1;
              }

            $adsf="update tbl_offer_banner set 
            fld_offer_banner_name='".$offer_banner_name."',
            fld_offer_banner_image='".$photo."',
            fld_offer_banner_description='".$description."'
            where fld_offer_banner_id='".$_GET['id']."'";         

            $update=mysqli_query($connect, $adsf) or die(mysqli_error($connect));

            $back="offer_banner_update.php?id='".$_GET['id']."'";
            if($update)
            {
                echo "<script>";
                echo "alert('Banner Updated');";
                echo "window.location.href='offer_banner_view.php';";
                echo "</script>";
            }
            else
            {
                echo "<script>";
                echo "alert('Error');";
                // echo "window.location.href='".$back."'";
                echo "</script>";
            }
        
    }
?>