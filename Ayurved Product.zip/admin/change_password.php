<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Update Password</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Update Password</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Update Password</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                
                <div class="col-lg-12 col-md-12">
                    
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="project" aria-expanded="true">
                            <div class="row clearfix">
                                  
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2><strong>Change</strong> Password</h2>
                                        </div><hr>
                                        <div class="body">
                                            <form  onsubmit="return validateForm()" method="post" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <input type="password" class="form-control" placeholder="Current Password" name="old_password">
                                            </div>
                                            <div class="form-group">
                                                <input type="password" class="form-control" placeholder="New Password" name="new_password">
                                            </div>
                                            <div class="form-group">
                                                <input type="password" class="form-control" placeholder="Re-type New Password" name="retype_password">
                                            </div>
                                            <center><button class="btn btn-info btn-round" type="submit" name="update">Update Password</button></center>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>


<?php
    if(isset($_POST['update'])) 

    {
     extract($_POST);
     $updt = 'select * from tbl_admin where admin_password="'.$_POST['old_password'].'" and admin_email ="'.$_SESSION['email'].'"';

    $res=mysqli_query($connect,$updt);

    if(mysqli_num_rows($res)>0)
    {

        if(strlen($_POST['new_password'])>=5 )
          {
              if($_POST['new_password']==$_POST['retype_password'])
              {
                $query1='update tbl_admin set admin_password="'.$_POST['new_password'].'" where admin_email ="'.$_SESSION['email'].'" ';   
                  $res=mysqli_query($connect,$query1);

                  echo '<script type="text/javascript">';
                  echo 'alert("password changed Successfully !!!! ");';
                  echo 'window.location.href = "index.php";';
                  echo '</script>';
              }
              else
              {
              echo '<script type="text/javascript">';
              echo 'alert(" password is not matched...try again !!!! ");';
              echo 'window.location.href = "change_password.php";';
              echo '</script>';
              }
          }
          else
          {
              echo '<script type="text/javascript">';
              echo 'alert("password length not match");';
              echo 'window.location.href = "change_password.php";';
              echo '</script>';
          }
    } 
    else
    {
        echo '<script type="text/javascript">';
        echo 'alert("Old password is not matched...try again ");';
        // $query1;
        echo 'window.location.href = "change_password.php";';
        echo '</script>';
               

    }
    }
?>