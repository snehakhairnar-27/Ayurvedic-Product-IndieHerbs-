<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Home Slider Add</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <style>
            .preview_box{clear: both; padding: 5px; margin-top: 10px; text-align:left;}
            .preview_box img{max-width: 100px; max-height: 100px;}
        </style>
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Home Slider</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Add Home Slider</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Home</strong> Slider Add</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="home_slider_view.php" class="btn btn-primary" role="button">
                                                        View Home Slider
                                                    </a>
                                                </li>
                                            </ul>
                                        </div><hr>
                                        <div class="body">
                                            <form method="POST" class="form-horizontal form-bordered" onsubmit="return validateForm()" enctype="multipart/form-data">
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Slider Name<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input type="text" name="slider_name" id="slider_name" class="form-control"  placeholder="Enter slider name" required="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label>Photo<span style="color:red;">*</span></label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="row">
                                                            <div id="dvPreview"></div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <input class="form-control" name="fld_slider_image[]" id="fld_slider_image" type="file" multiple required="" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');" accept=" .jpg , .jpeg , .png ">
                                             
                                                            </div>
                                                        </div>
                                                        <span style="color: red;" >Please upload image png, jpg, jpeg Format in Width 1519 X Height 500 Size. You can select multiple images.</span> 
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                        <label >Slider Description</label>
                                                    </div>
                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                        <div class="form-group">
                                                            <div class="form-line">
                                                                <textarea rows="3" name="description" id="description" class="form-control no-resize" placeholder="Please type slider description"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <center>
                                                        <button type="submit" name="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button></center>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
    <script language="javascript" type="text/javascript">
            $(function () {
                $("#fld_slider_image").change(function () {
                    if (typeof (FileReader) != "undefined") {
                        var dvPreview = $("#dvPreview");
                        dvPreview.html("");
                        var regex = /^([a-zA-Z0-9()\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                        $($(this)[0].files).each(function () {
                            var file = $(this);
                            if (regex.test(file[0].name.toLowerCase())) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var img = $("<img/>");
                                    img.attr("style", "height:100px;width: 100px");
                                    img.attr("src", e.target.result);
                                    dvPreview.append(img);
                                }
                                reader.readAsDataURL(file[0]);
                            } else {
                                alert(file[0].name + " is not a valid image file.");
                                dvPreview.html("");
                                return false;
                            }
                        });
                    } else {
                        alert("This browser does not support HTML5 FileReader.");
                    }
                });
            });
        </script>

<?php   
        if(isset($_POST['submit']))
        {
            extract($_POST);
            
            
                if(isset($_FILES['fld_slider_image']))
                {   
                    $errors= array();
                    foreach($_FILES['fld_slider_image']['tmp_name'] as $key => $tmp_name )
                    {
                        $file_name = $key.$_FILES['fld_slider_image']['name'][$key];
                        $file_size =$_FILES['fld_slider_image']['size'][$key];
                        $file_tmp =$_FILES['fld_slider_image']['tmp_name'][$key];
                        $file_type=$_FILES['fld_slider_image']['type'][$key];  

                        $slider_image=uniqid().$file_name;
                       
                        $extension = strtolower(pathinfo($slider_image,PATHINFO_EXTENSION));

                       if($extension=="jpg" || $extension=="jpeg" || $extension=="png")
                        {  
                         
                           $query="INSERT into tbl_home_slider(fld_slider_name, fld_slider_image,fld_slider_description) VALUES('$slider_name','$slider_image','$description') ";

                            $desired_dir="../images/slider/";
                            move_uploaded_file($file_tmp,"$desired_dir".$slider_image);

                            $slide=mysqli_query($connect, $query); 

                            $save = "$desired_dir" . $slider_image; //This is the new file you saving
                            $file = "$desired_dir" . $slider_image; //This is the original file

                            list($width, $height) = getimagesize($file) ;

                            $modwidth = 1519;                  
                            $modheight = 500;
                            $tn = imagecreatetruecolor($modwidth, $modheight) ;
                            imagealphablending( $tn, false );
                            imagesavealpha( $tn, true );
                            if($extension=="jpg" || $extension=="jpeg" )
                            {

                                $image = imagecreatefromjpeg($file);
                                 imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagejpeg($tn, $save, 100); 
                            }
                            else if($extension=="png")
                            {

                                $image = imagecreatefrompng($file);
                                imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagepng( $tn, $save, 9 );
                            }   
                        }
                    }
                }

                if($slide)
                {
                    echo "<script>";
                    echo "alert('Record Inserted Successfully');";
                    echo "window.location.href='home_slider_view.php';";
                    echo "</script>";
                }
                else
                {
                    echo "<script>";
                    echo "alert('Oops Error Occured');";
                    echo "window.location.href='home_slider_view.php';";
                    echo "</script>";
                }                   
        }
    ?>