<?php 
include "../config.php";
if(isset($_GET['id']))
{
	$del=mysqli_query($connect,"update tbl_subcategory set fld_subcategory_delete=1 where fld_subcategory_id='".$_GET['id']."'") or die(mysqli_error($connect));

		$back="javascript:history.back()";
		if($del)
			{
				echo "<script>";
				echo "alert('Sub Category Name Deleted');";
				echo "window.location.href='subcategory_view.php';";
				echo "</script>";
			}
			else
			{
				echo "<script>";
				echo "alert('Error');";
				echo "window.location.href='subcategory_view.php';";
				echo "</script>";
			}
}
?>