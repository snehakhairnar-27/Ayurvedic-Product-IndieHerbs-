<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<title>Ayurved - Admin</title>
	<!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">

	<!-- Plugins Core Css -->
	<link href="assets/css/app.min.css" rel="stylesheet">

	<!-- Custom Css -->
	<link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/pages/extra_pages.css" rel="stylesheet" />
</head>

<body class="login-page">
	<?php include"../config.php";?>
	<div class="limiter">
		<div class="container-login100 page-background">
			<div class="wrap-login100">
				<form method="post">
					<span class="login100">
						<img alt="" src="../images/Ayurvedics.png" >
					</span>
					<span class="login100-form-title p-b-34 p-t-27">
						Log in
					</span>
					<div class="wrap-input100 validate-input" data-validate="Enter name">
						<input class="input100" type="email" name="admin_email" placeholder="Username">
						<i class="material-icons focus-input1001">person</i>
					</div>
					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="admin_paasword" placeholder="Password">
						<i class="material-icons focus-input1001">lock</i>
					</div>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type="submit" name="login">
							Login
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- Plugins Js -->

    <?php include'footer.php'?>

    <?php

    if(isset($_POST['login']))
    {
        extract($_POST);

        $email=mysqli_real_escape_string($connect,$_POST['admin_email']);
        $password=mysqli_real_escape_string($connect,$_POST['admin_paasword']);
        
        $log=mysqli_query($connect,"select * from tbl_admin where admin_email='$email' and admin_password='$password'") or die (mysqli_error($connect));
            
        if(mysqli_num_rows($log)>0)
        {
            $fetch=mysqli_fetch_array($log);
            
            $_SESSION['id']=$fetch['admin_id'];
            $_SESSION['email']=$fetch['admin_email'];     
            $_SESSION['photo']=$fetch['admin_photo'];     
                  
            
            echo "<script>";
            echo "alert('Login Successfull');";
            echo 'window.location.href="dashboard.php";';
            echo "</script>";
        }else
        {
            echo "<script>";
            echo "alert('Login Failed');";
            echo "</script>";
            
        }
        
    }

?>