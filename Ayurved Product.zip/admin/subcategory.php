<?php

	include "../config.php";

	if(isset($_POST["product_category"]))
	{
		$str="select * from tbl_subcategory where fld_product_category_id='".$_POST['product_category']."' and fld_subcategory_delete=0 ";
		$select1=mysqli_query($connect,$str) or die(mysqli_error($connect));
?>
			<option value="">Select Company Brand</option>
		
<?php 	  
		 while($row=mysqli_fetch_array($select1))
		{
?>
			<option value="<?php echo $row['fld_subcategory_id'];?>"><?php echo $row['fld_subcategory_name'];?></option>
<?php

		}
	}	 
		
?>