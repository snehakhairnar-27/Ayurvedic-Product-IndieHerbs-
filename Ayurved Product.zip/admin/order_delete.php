<?php 
include "../config.php";
if(isset($_GET['oid']))
{
	$del=mysqli_query($connect,"update tbl_order_add set fld_order_delete=1 where fld_order_id='".$_GET['oid']."'") or die(mysqli_error($connect));

		
		if($del)
			{
				echo "<script>";
				echo "alert('Order Deleted');";
				echo "window.location.href='order_view.php';";
				echo "</script>";
			}
			else
			{
				echo "<script>";
				echo "alert('Error');";
				echo "window.location.href='order_view.php';";
				echo "</script>";
			}
}
?>