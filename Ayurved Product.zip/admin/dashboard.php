<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Dashboard</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
</head>

<body class="light">
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include "header.php";?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Dashboard</h4>
                            </li>
                            <li class="breadcrumb-item active">Home</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_home_slider order by fld_slider_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-green">
                        <a href="home_slider_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fa fa-images"></h1>
                        </div>
                        <div class="text m-b-10">Home Sliders</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_offer_banner order by fld_offer_banner_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-orange">
                        <a href="offer_banner_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fa fa-film"></h1>
                        </div>
                        <div class="text m-b-10">Offer Banner</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_product_banner order by fld_product_banner_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-black">
                        <a href="product_banner_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fa fa-film"></h1>
                        </div>
                        <div class="text m-b-10">Product Banner</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_subcategory order by fld_subcategory_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-blue">
                        <a href="subcategory_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fas fa-hotel"></h1>
                        </div>
                        <div class="text m-b-10">Product Sub-category</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_product_category order by fld_product_category_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-purple">
                        <a href="product_category_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fa fa-braille"></h1>
                        </div>
                        <div class="text m-b-10">Product Category</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <?php 
                        $query_sprofile1="select * from tbl_product order by fld_product_id desc";
                        $view_sprofile1=mysqli_query($connect,$query_sprofile1);
                    ?>
                    <div class="support-box text-center bg-red">
                        <a href="product_view.php" style="text-decoration: none;color: white;">
                        <div class="icon m-b-10">
                            <h1 class="fa fa-layer-group"></h1>
                        </div>
                        <div class="text m-b-10">Product</div>
                        <h3 class="m-b-0"><?php echo mysqli_num_rows($view_sprofile1) ?>
                            
                        </h3>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include'footer.php';?>