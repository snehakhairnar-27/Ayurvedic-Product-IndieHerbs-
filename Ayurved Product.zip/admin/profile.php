<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Profile</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    <style>
            .preview_box{clear: both; padding: 5px; margin-top: 10px; text-align:left;}
            .preview_box img{max-width: 200px; max-height: 100px;}
        </style>
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        <?php
                     if($_GET['p_id']==0)
                            {
                                $fld_name="";
                                $fld_logo="";
                                $fld_description="";
                                $fld_address="";
                                $fld_google_map="";
                                $fld_mobile="";
                                $fld_phone="";
                                $fld_email="";
                                $fld_copyright="";
                                $fld_website="";                                
                                $fld_facebook=""; 
                                $fld_twitter="";
                                $fld_linkedin="";
                                $fld_instagram="";
                                $fld_whatsapp_link="";
                                $fld_delivery_charges="";
                                $fld_invoice_prefix="";
                            }
                            else
                            {
                                $query=mysqli_query($connect,"select * from tbl_my_profile where fld_id='".$_GET['p_id']."' ") or die(mysqli_error($connect));
                                $fetch=mysqli_fetch_array($query);
                                extract($fetch);

                                $fld_logo=$fld_logo;
                                $fld_name=$fld_name;
                                $fld_description=$fld_description;
                                $fld_address=$fld_address;
                                $fld_google_map=$fld_google_map;
                                $fld_mobile=$fld_mobile;
                                $fld_phone=$fld_phone;
                                $fld_email=$fld_email;
                                $fld_copyright=$fld_copyright;
                                $fld_website=$fld_website;
                                $fld_facebook=$fld_facebook; 
                                $fld_twitter=$fld_twitter;
                                $fld_linkedin=$fld_linkedin; 
                                $fld_instagram=$fld_instagram;
                                $fld_whatsapp_link=$fld_whatsapp_link;
                                $fld_delivery_charges=$fld_delivery_charges;
                                $fld_invoice_prefix=$fld_invoice_prefix;
                                
                            }
                       ?>                      
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Update Profile</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Update Profile</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2><strong>Profile</strong> Update</h2>
                                        </div><hr>
                                        <div class="body">
                                            <div class="row clearfix">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="card">
                                                        <div class="body">
                                                            <form method="post" class="form-horizontal" enctype="multipart/form-data">
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Name<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="name" class="form-control" placeholder="Enter name" required="" value="<?php echo $fld_name; ?>" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Logo<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                            
                                                                            <div class="row">
                                                                                <div class="preview_box">
                                                                                    <div class="image">
                                                                                        <?php
                                                                                            if($fld_logo!="")
                                                                                                { 
                                                                                                    ?>
                                                                                                    <img id="preview_img" src="../images/<?php echo $fld_logo?>" height="75" width="175"/>

                                                                                                    <?php 
                                                                                                } 
                                                                                                else 
                                                                                                { 
                                                                                                    ?>
                                                                                                        <img id="preview_img" src="../images/No-image-full.jpg" height="75" width="175" />
                                                                                                    <?php 
                                                                                                } 
                                                                                        ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div><br>
                                                                            <div class="form-group">
                                                                                <div class="form-line">
                                                                                    <input class="form-control" name="fld_logo" id="image" type="file" value="<?php echo $fld_logo; ?>" oninput="this.value = this.value.replace(/[^a-zA-Z\s]/g, '').replace(/(\..*)\./g, '$1');" accept=" .jpg , .jpeg , .png ">

                                                                                </div>
                                                                            </div>
                                                                        
                                                                        <script>
                                                                            function fileValidation() {
                                                                            var fileInput =
                                                                            document.getElementById('image');

                                                                            var filePath = fileInput.value;

                                                                            // Allowing file type 
                                                                            var allowedExtensions =
                                                                            /(\.jpg|\.jpeg|\.png)$/i;

                                                                            if (!allowedExtensions.exec(filePath)) {
                                                                               alert('Invalid Image type');
                                                                              fileInput.value = '';
                                                                            return false;
                                                                            }

                                                                            }
                                                                        </script>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Email<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="email" name="email" class="form-control" placeholder="Enter email address" value="<?php echo $fld_email; ?>" pattern="^(([-\w\d]+)(\.[-\w\d]+)*@([-\w\d]+)(\.[-\w\d]+)*(\.([a-zA-Z]{2,5}|[\d]{1,3})){1,2})$" required="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Address<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="address" class="form-control" placeholder="Enter Address" value="<?php echo $fld_address; ?>" required="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label >Description<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="description" class="form-control" required=""><?php echo $fld_description; ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Google Map<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <textarea name="google_map" class="form-control" required=""><?php echo $fld_google_map; ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Telephone</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" class="form-control" name="phone" placeholder="Enter Telephone Number" value="<?php echo $fld_phone; ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" maxlength="15" minlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Mobile Number<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile Number" required="" value="<?php echo $fld_mobile; ?>" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" minlength="10">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Whatsapp Link</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                 <input type="text" name="whatsapp_link" class="form-control"  placeholder="Enter Whatsapp Link" value="<?php echo $fld_whatsapp_link; ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label >Facebook Link</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="facebook" class="form-control"  placeholder="Enter Facebook Link" value="<?php echo $fld_facebook; ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Instagram Link</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="instagram" class="form-control" placeholder="Enter Instagram Link" value="<?php echo $fld_instagram; ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Twitter Link</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="twitter" class="form-control" placeholder="Enter Twitter Link" value="<?php echo $fld_twitter; ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Linkedin Link</label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="linkedin" class="form-control" placeholder="Enter Linkedin Link" value="<?php echo $fld_linkedin; ?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Website Link<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="website" class="form-control" placeholder="Enter Website Link" value="<?php echo $fld_website; ?>" required="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Delivery Charges<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="delivery_charges" class="form-control" placeholder="Enter Delivery Charges" value="<?php echo $fld_delivery_charges; ?>" required="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Invoice Prefix<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                <input type="text" name="invoice_prefix" class="form-control" placeholder="Enter Invoice Prefix" value="<?php echo $fld_invoice_prefix; ?>" required="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                        <label>Copyright<span style="color:red;">*</span></label>
                                                                    </div>
                                                                    <div class="col-lg-10 col-md-10 col-sm-8 col-xs-7">
                                                                        <div class="form-group">
                                                                            <div class="form-line">
                                                                                 <textarea name="copyright" class="form-control" required=""><?php echo $fld_copyright; ?></textarea>

                                                                            </div>
                                                                            <span style="color:red;">Please use &amp;#169; for copyright (&#169;)</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row clearfix">
                                                                    <div class="col-lg-12 col-md-12 col-sm-8 col-xs-7">
                                                                        <center><button type="submit" name="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button></center>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>

    <script type="text/javascript">
        $(document).ready(function(){
            //Image file input change event
            $("#image").change(function(){
                readImageData(this);//Call image read and render function
            });
        });
        function readImageData(imgData){
            if (imgData.files && imgData.files[0]) {
                var readerObj = new FileReader();
                readerObj.onload = function (element) {
                    $('#preview_img').attr('src', element.target.result);
                }
                readerObj.readAsDataURL(imgData.files[0]);
            }
        }
    </script>

<?php 

    if(isset($_POST['submit']))
    {
        extract($_POST);
        $back="profile.php?p_id=".$_GET['p_id']."";
    
        if($_GET['p_id']==0)
        {
            $name=$_FILES['fld_logo']['name'];
            $size=$_FILES['fld_logo']['size'];
            $type=$_FILES['fld_logo']['type'];
            $temp=$_FILES['fld_logo']['tmp_name'];


            $extension1 = strtolower(pathinfo($name,PATHINFO_EXTENSION));

            if($extension1=="jpg" || $extension1=="jpeg" || $extension1=="png")
            {

                if($name)
                {
                        $desired_dir="../images/";             
                        $fld_logo=uniqid().$name;
                        $extension = strtolower(pathinfo($fld_logo,PATHINFO_EXTENSION));
                        
                         move_uploaded_file($temp,"$desired_dir/".$fld_logo);
                        // $a1 = $a;
                        $save = "$desired_dir" . $fld_logo; //This is the new file you saving
                        $file = "$desired_dir" . $fld_logo; //This is the original file

                        list($width, $height) = getimagesize($file) ;

                        $modwidth = 317;
                        $modheight = 90;
                        $tn = imagecreatetruecolor($modwidth, $modheight) ;
                        if($extension=="jpg" || $extension=="jpeg" )
                        {
                            $image = imagecreatefromjpeg($file);
                            imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                            imagejpeg($tn, $save, 100); 
                        }
                        else 
                        if($extension=="png")
                        {
                            $image = imagecreatefrompng($file);
                            imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                            imagepng( $tn, $save, 9 );
                        }
                }

                $profile="INSERT INTO tbl_my_profile(fld_name, fld_logo, fld_description, fld_address, fld_google_map, fld_mobile, fld_phone, fld_email, fld_copyright, fld_website,  fld_facebook, fld_twitter, fld_linkedin, fld_instagram, fld_whatsapp_link,fld_delivery_charges,fld_invoice_prefix) values('$name', '$fld_logo', '$description', '$address', '$google_map', '$mobile','$phone', '$email', '$copyright','$website', '$facebook', '$twitter', '$linkedin', '$instagram', '$whatsapp_link','$delivery_charges','$invoice_prefix')";

                $add=mysqli_query($connect,$profile) or die(mysqli_error($connect));

                $query_profile="select * from tbl_my_profile where fld_name='".$name."' and fld_description='".$description."' and fld_address='".$address."' and fld_google_map='".$google_map."' and fld_mobile='".$mobile."' and fld_phone='".$phone."' and fld_email='".$email."' and fld_copyright='".$copyright."' and fld_website='".$website."' and fld_facebook='".$facebook."' and fld_twitter='".$twitter."' and fld_linkedin='".$linkedin."' and fld_instagram='".$instagram."' and fld_whatsapp_link='".$whatsapp_link."' and fld_delivery_charges='".$delivery_charges."' and fld_invoice_prefix='".$invoice_prefix."' order by fld_id desc limit 1";

                $view_profile=mysqli_query($connect,$query_profile);
                $fetch_profile=mysqli_fetch_array($view_profile);

                $back1="my_profile.php?p_id=".$fetch_profile['fld_id']."";
     
                 if($add)
                    {
                       echo '<script type="text/javascript">';
                       echo " alert('Profile Added Successfully.');";
                       echo 'window.location.href = "'.$back1.'"';
                       echo '</script>';
              
                    }
                    else
                    {
                       echo '<script type="text/javascript">';
                       echo " alert('Error In Adding  Profile.');";
                       echo 'window.location.href = "'.$back.'"';
                       echo '</script>';           
              
                    }

            }
            else
            {
               echo '<script type="text/javascript">';
               echo " alert('Please Upload Valid Image File');";
               // echo 'window.location.href = "index.php";';
               echo '<script>';
                            
      
            }
        }
        else
        {

            $name=$_FILES['fld_logo']['name'];
            $size=$_FILES['fld_logo']['size'];
            $type=$_FILES['fld_logo']['type'];
            $temp=$_FILES['fld_logo']['tmp_name'];

            if($name)
                {

                    $extension1 = strtolower(pathinfo($name,PATHINFO_EXTENSION));

                    if($extension1=="jpg" || $extension1=="jpeg" || $extension1=="png")
                    {
                        $desired_dir="../images/";  
                        unlink($desired_dir.$fetch['fld_logo']);             
                        $fld_logo=uniqid().$name;
                        $extension = strtolower(pathinfo($fld_logo,PATHINFO_EXTENSION));
                
                        move_uploaded_file($temp,"$desired_dir/".$fld_logo);
                        // $a1 = $a;
                        $save = "$desired_dir" . $fld_logo; //This is the new file you saving
                        $file = "$desired_dir" . $fld_logo; //This is the original file

                        list($width, $height) = getimagesize($file) ;

                        $modwidth = 268.5;
                        $modheight = 69;
                        $tn = imagecreatetruecolor($modwidth, $modheight) ;
                            imagealphablending( $tn, false );
                            imagesavealpha( $tn, true );
                            if($extension=="jpg" || $extension=="jpeg" )
                            {

                                $image = imagecreatefromjpeg($file);
                                imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagejpeg($tn, $save, 100); 
                            }
                            else if($extension=="png")
                            {

                                $image = imagecreatefrompng($file);
                                imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ;
                                imagepng( $tn, $save, 9 );
                            }
                    }
                    else
                    {
                       echo '<script type="text/javascript">';
                       echo " alert('Please Upload Valid Image File');";
                       // echo 'window.location.href = "index.php";';
                       echo '<script>';
                    
                    }
                }
                else
                {
                    $fld_logo=$fetch['fld_logo'];
                }  

         $qw="update tbl_my_profile set 
        fld_logo='".$fld_logo."',
        fld_name='".$_POST['name']."',
        fld_description='".$_POST['description']."',
        fld_address='".$_POST['address']."',
        fld_google_map='".$_POST['google_map']."',
        fld_mobile='".$_POST['mobile']."',
        fld_phone='".$_POST['phone']."',
        fld_email='".$_POST['email']."',
        fld_copyright='".$_POST['copyright']."',
        fld_website='".$website."', 
        fld_facebook='".$facebook."', 
        fld_twitter='".$twitter."',
        fld_linkedin='".$linkedin."', 
        fld_instagram='".$instagram."',
        fld_whatsapp_link='".$whatsapp_link."',
        fld_delivery_charges='".$delivery_charges."',
        fld_invoice_prefix='".$invoice_prefix."'
        where fld_id='".$_GET['p_id']."'";
      
         $update=mysqli_query($connect,$qw) or die(mysqli_error($connect));
         
         if($update)
         {
           echo '<script type="text/javascript">';
           echo " alert('Profile Updated Successfully.');";
            echo 'window.location.href = "'.$back.'"';
           echo '</script>';
  
         }
         else
         {
           echo '<script type="text/javascript">';
           echo " alert('Error In Updating  Profile.');";
           echo 'window.location.href = "'.$back.'"';
           echo '</script>';
         }
    }
}

?>