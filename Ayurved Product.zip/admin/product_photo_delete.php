<?php include "../config.php";
	if(isset($_GET['photo_id']))
	{
		
		 $delete_photo=mysqli_query($connect,"update tbl_product_photo set fld_product_photo_delete=1 where fld_product_photo_id='".$_GET['photo_id']."'") or die(mysqli_error($connect));


		$back="product_photo_update.php?id=".$_GET['product_id'];

		if($delete_photo)
			{
					echo "<script>";
					echo "alert('Product Photo Deleted');";
					echo "window.location.href='".$back."'";
					echo "</script>";
				}
				else
				{
					echo "<script>";
					echo "alert('Error');";
					echo "window.location.href='".$back."'";
					echo "</script>";
				}
	}
?>

