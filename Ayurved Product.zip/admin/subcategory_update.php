<?php
include "../config.php";
if (isset($_POST['update'])) 
    {
        
        extract($_POST);

        $product_name=$_POST['product_category'];
        $sub_product_name1=$_POST['subcategory_name'];
        $sub_product=ucwords(strtolower($sub_product_name1));
        $coulmn=array();
        $query1=mysqli_query($connect,"select * from tbl_subcategory where fld_subcategory_name='".$sub_product."' and fld_product_category_id='".$_POST['product_category']."' and fld_subcategory_id!='".$_GET['subcategory_id']."' and fld_subcategory_delete=0 ");
       
        if (mysqli_num_rows($query1)==1) 
        {
          echo '<script type="text/javascript">'; 
          echo 'alert("Sub Category Name Is Already Exist");';
          echo "window.location.href = 'subcategory_view.php';";
          echo '</script>'; 

        }    
        else
        {

            $query="Update tbl_subcategory set fld_subcategory_name='".$subcategory_name."', fld_product_category_id='".$_POST['product_category']."' where fld_subcategory_id='".$_GET['subcategory_id']."' ";
            //echo $query."<br>";
            $row=mysqli_query($connect,$query) or die(mysqli_error($connect));
            if ($row) 
            {
              echo '<script type="text/javascript">';
              echo "alert('Sub Category Name Updated');";
              echo 'window.location.href = "subcategory_view.php";';
              echo "</script>";

            }
           else
            {
              echo '<script type="text/javascript">';
              echo "alert('Error in Updating');";
              echo 'window.location.href = "subcategory_view.php";';
              echo "</script>";
               
            }
        }    
    }    

?>
