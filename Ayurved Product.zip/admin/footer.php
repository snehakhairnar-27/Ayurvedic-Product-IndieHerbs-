
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/chart.min.js"></script>
    <!-- Custom Js -->
    <script src="assets/js/admin.js"></script>
    <script src="assets/js/pages/dashboard/dashboard3.js"></script>
    <!-- Knob Js -->
    <script src="assets/js/pages/todo/todo.js"></script>
</body>

</html>