<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Home Slider</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    
</head>

<body class="light">
    <!-- Page Loader -->
    <!-- <div class="page-loader-wrapper">
        <div class="loader">
            <div class="m-t-30">
                <img class="loading-img-spin" src="../../assets/images/loading.png" width="20" height="20" alt="admin">
            </div>
            <p>Please wait...</p>
        </div>
    </div> -->
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Home Slider</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Home Slider</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Home</strong> Slider</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="home_slider_add.php" class="btn btn-primary" role="button">
                                                        Add Home Slider
                                                    </a>
                                                </li>
                                            </ul>
                                        </div><hr>
                                        <div class="body">
                                            <div class="bootstrap snippet">
                                                <section id="portfolio" class="gray-bg padding-top-bottom">
                                                    <div class="projects-container scrollimation in">
                                                        <div class="row">
                                                            <?php
                                                                $view = mysqli_query($connect,"select * from tbl_home_slider where fld_slider_delete=0 order by fld_slider_id desc") or die (mysqli_error($connect));
                                                                while ($fetch=mysqli_fetch_array($view))
                                                                {
                                                                    extract($fetch);

                                                            ?>
                                                            <article class="col-md-6 col-sm-6 portfolio-item web-design apps psd">
                                                                <div class="portfolio-thumb in">
                                                                    <a href="#" class="main-link">
                                                                        <img class="img-responsive img-center"
                                                                            src="../images/slider/<?php echo $fetch['fld_slider_image']?>" alt="" width="100%">
                                                                        <span class="overlay-mask"></span>
                                                                    </a>
                                                                    
                                                                    <a class="enlarge cboxElement" href="home_slider_update.php?id=<?php echo $fetch['fld_slider_id']; ?>" title="Slider Update"><i class="fa fa-edit fa-fw"></i></a>
                                                                    <a class="link" href="home_slider_delete.php?id=<?php echo $fetch['fld_slider_id']; ?>" title="Slider Delete"><i class="fa fa-trash fa-fw"></i></a>
                                                                </div>
                                                            </article>
                                                            <?php }?>
                                                        </div>
                                                    </div>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
    <script language="javascript" type="text/javascript">
            $(function () {
                $("#fld_slider_image").change(function () {
                    if (typeof (FileReader) != "undefined") {
                        var dvPreview = $("#dvPreview");
                        dvPreview.html("");
                        var regex = /^([a-zA-Z0-9()\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
                        $($(this)[0].files).each(function () {
                            var file = $(this);
                            if (regex.test(file[0].name.toLowerCase())) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    var img = $("<img/>");
                                    img.attr("style", "height:100px;width: 100px");
                                    img.attr("src", e.target.result);
                                    dvPreview.append(img);
                                }
                                reader.readAsDataURL(file[0]);
                            } else {
                                alert(file[0].name + " is not a valid image file.");
                                dvPreview.html("");
                                return false;
                            }
                        });
                    } else {
                        alert("This browser does not support HTML5 FileReader.");
                    }
                });
            });
        </script>
