<?php
    session_start();
    // echo $_SESSION['email'];
    if(!isset($_SESSION['id']))
    {
        echo "<script>";
        echo 'window.location.href="index.php";';
        echo "</script>";
    }
    include "../config.php";
?>
<!-- Top Bar -->
<?php 
    $admin_query=mysqli_query($connect,"select * from tbl_admin where admin_email='".$_SESSION['email']."' ")or die (mysqli_error($connect));

    $fetch=mysqli_fetch_array($admin_query);
    extract($fetch);
?>
<nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="#" onClick="return false;" class="navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="#" onClick="return false;" class="bars"></a>
                <a class="navbar-brand" href="dashboard.php">
                    <img src="../images/62dd93ed684cbAyurvedics (1).png"  alt=""/>
                </a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="pull-left">
                    <li>
                        <a href="#" onClick="return false;" class="sidemenu-collapse">
                            <i class="material-icons">reorder</i>
                        </a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <!-- Full Screen Button -->
                    <li class="fullscreen">
                        <a href="javascript:;" class="fullscreen-btn">
                            <i class="fas fa-expand"></i>
                        </a>
                    </li>
                    <li class="dropdown user_profile">
                        <a href="#" onClick="return false;" class="dropdown-toggle" data-toggle="dropdown"
                            role="button">
                            <img src="../images/<?php echo $fetch['admin_photo']; ?>" width="32" height="32" alt="User">
                        </a>
                        <ul class="dropdown-menu pullDown">
                            <li class="body">
                                <ul class="user_dw_menu">
                                    <li>
                                        <a href="update_profile.php" title="Update Profile">
                                            <i class="material-icons">person</i>Update Profile
                                        </a>
                                    </li>
                                    <li>
                                        <a href="change_password.php" title="Change Password">
                                            <i class="material-icons">feedback</i>Change Password
                                        </a>
                                    </li>
                                    <li>
                                        <a href="logout.php" title="logout">
                                            <i class="material-icons">power_settings_new</i>Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!-- #END# Tasks -->
                    <li class="pull-right">
                        <a href="#" onClick="return false;" class="js-right-sidebar" data-close="true">
                            <i class="fas fa-cog"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <div>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="sidebar-user-panel active">
                        <div class="user-panel">
                            <div class=" image">
                                <img src="../images/<?php echo $fetch['admin_photo']; ?>" class="img-circle user-img-circle"
                                    alt="User Image" />
                            </div>
                        </div>
                        <div class="profile-usertitle">
                            <div class="sidebar-userpic-name"> <?php echo $fetch['admin_name']; ?> </div>
                            <div class="profile-usertitle-job "> <?php echo $fetch['admin_email']; ?> </div>
                        </div>
                    </li>
                    <li class="active">
                        <a href="dashboard.php">
                            <i class="fa fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <?php
                        $profile=mysqli_query($connect,"select * from tbl_my_profile where fld_delete=0 order by fld_id desc limit 1");
                        if(mysqli_num_rows($profile)==0)
                        {
                    ?><li>
                        <a href="profile.php?p_id=0">
                            <i class="far fa-id-card"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                    
                    <?php
                        }else
                        {
                             $fetch=mysqli_fetch_array($profile);
                    ?>  <li>
                            <a href="profile.php?p_id=<?php echo $fetch['fld_id']; ?>">
                                <i class="far fa-id-card"></i>
                                <span>Profile</span>
                            </a>
                        </li>
                        <!--  -->
                    <?php } ?>
                    
                    <li>
                        <a href="home_slider_view.php">
                            <i class="far fa-images"></i>
                            <span>Home Slider</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i class="fas fa-film"></i>
                            <span>Banner</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="offer_banner_view.php">Offer Banner</a>
                            </li>
                            <li>
                                <a href="product_banner_view.php">Product Banner</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="product_category_view.php">
                            <i class="fas fa-braille"></i>
                            <span>Product Category</span>
                        </a>
                    </li>
                    <li>
                        <a href="subcategory_view.php">
                            <i class="fas fa-hotel"></i>
                            <span>Product Sub Category</span>
                        </a>
                    </li>
                    <li>
                        <a href="product_view.php">
                            <i class="fa fa-layer-group"></i>
                            <span>Product</span>
                        </a>
                    </li>
                    <li>
                        <a href="order_view.php">
                            <i class="fa fa-hotel"></i>
                            <span>User Order</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" onClick="return false;" class="menu-toggle">
                            <i class="fas fa-cogs"></i>
                            <span>Setting</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="update_profile.php">Update Profile</a>
                            </li>
                            <li>
                                <a href="change_password.php">Change Password</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="logout.php">
                            <i class="fas fa-power-off"></i>
                            <span>Log Out</span>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        <aside id="rightsidebar" class="right-sidebar">
            <ul class="nav nav-tabs tab-nav-right" role="tablist">
                <li role="presentation">
                    <a href="#skins" data-toggle="tab" class="active">SKINS</a>
                </li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane in active in active stretchLeft" id="skins">
                    <div class="demo-skin">
                        <div class="rightSetting">
                            <p>SIDEBAR MENU COLORS</p>
                            <button type="button"
                                class="btn btn-sidebar-light btn-border-radius p-l-20 p-r-20">Light</button>
                            <button type="button"
                                class="btn btn-sidebar-dark btn-default btn-border-radius p-l-20 p-r-20">Dark</button>
                        </div>
                        <div class="rightSetting">
                            <p>THEME COLORS</p>
                            <button type="button"
                                class="btn btn-theme-light btn-border-radius p-l-20 p-r-20">Light</button>
                            <button type="button"
                                class="btn btn-theme-dark btn-default btn-border-radius p-l-20 p-r-20">Dark</button>
                        </div>
                        <div class="rightSetting">
                            <p>SKINS</p>
                            <ul class="demo-choose-skin choose-theme list-unstyled">
                                <li data-theme="black" class="actived">
                                    <div class="black-theme"></div>
                                </li>
                                <li data-theme="white">
                                    <div class="white-theme white-theme-border"></div>
                                </li>
                                <li data-theme="purple">
                                    <div class="purple-theme"></div>
                                </li>
                                <li data-theme="blue">
                                    <div class="blue-theme"></div>
                                </li>
                                <li data-theme="cyan">
                                    <div class="cyan-theme"></div>
                                </li>
                                <li data-theme="green">
                                    <div class="green-theme"></div>
                                </li>
                                <li data-theme="orange">
                                    <div class="orange-theme"></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </aside>
        <!-- #END# Right Sidebar -->
    </div>