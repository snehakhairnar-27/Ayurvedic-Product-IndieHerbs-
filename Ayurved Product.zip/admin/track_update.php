<?php
include "../config.php";
if (isset($_POST['update'])) 
    {
        
        extract($_POST);

            $query="Update tbl_order_add set fld_order_status='".$status."' where fld_order_id='".$_GET['tid']."' ";
           
            $row=mysqli_query($connect,$query) or die(mysqli_error($connect));
            if ($row) 
            {
              echo '<script type="text/javascript">';
              echo "alert('Status Updated');";
              echo 'window.location.href = "order_view.php";';
              echo "</script>";

            }
           else
            {
              echo '<script type="text/javascript">';
              echo "alert('Error in Updating');";
              echo 'window.location.href = "order_view.php";';
              echo "</script>";
               
            }
        
    }    

?>
