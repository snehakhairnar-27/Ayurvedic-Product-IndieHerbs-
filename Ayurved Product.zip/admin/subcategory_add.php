<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Ayurved - Sub Category Add</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon-logo.png" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- You can choose a theme from css/styles instead of get all themes -->
    <link href="assets/css/styles/all-themes.css" rel="stylesheet" />
    
</head>

<body class="light">
    
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <?php include'header.php';?>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                        <ul class="breadcrumb breadcrumb-style ">
                            <li class="breadcrumb-item">
                                <h4 class="page-title">Sub Category</h4>
                            </li>
                            <li class="breadcrumb-item bcrumb-1">
                                <a href="dashboard.php">
                                    <i class="fas fa-home"></i> Home</a>
                            </li>
                            <li class="breadcrumb-item active">Add Sub Category</li>
                        </ul>

                    </div>
                </div>
            </div>
            <!-- Your content goes here  -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active">
                            <div class="row clearfix">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="card">
                                        <div class="header">
                                            <h2>
                                                <strong>Sub </strong> Category</h2>
                                            <ul class="header-dropdown m-r--5">
                                                <li class="dropdown">
                                                    <a href="subcategory_view.php" class="btn btn-primary" role="button">
                                                        View Sub Category
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="body">
                                            <form method="POST" class="form-horizontal form-bordered" >
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <div class="row clearfix">
                                                            <div class="col-lg-1 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                                                <label>Product Category</label>
                                                            </div>
                                                            <div class="col-lg-11 col-md-10 col-sm-8 col-xs-7">
                                                                <div class="form-group default-select select2Style">
                                                                    <select class="form-control select2" data-placeholder="Select" name="product_category" id="product_category">
                                                                        <option value="">Select Product Category</option>
                                                                        <?php
                                                                            $query=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_delete=0 order by fld_product_category_name asc ");
                                                                        
                                                                            while($row=mysqli_fetch_assoc($query))
                                                                            {
                                                                                extract($row);
                                                                         ?>
                                                                        <option value="<?php echo $row['fld_product_category_id'];?>"><?php echo $row['fld_product_category_name'];?></option>
                                                                    <?php }?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">  
                                                    <div class="body table-responsive">
                                                        <table class="table" id="pd">
                                                            <tbody>
                                                                <tr class="tr-header">
                                                                    <th><a href="javascript:void(0);" id="addMore" title="Add More"><span class="fa fa-plus text-success"></span></a></th>
                                                                    <th>Sub Category <span class="text-danger">*</span> : </th>
                                                                </tr>
                                                                <tr>
                                                                    <td><a href='javascript:void(0);' class='remove'><span class='fa fa-minus text-danger'></span></a></td>
                                                                    <td><input type="text" name="subcategory[]" id="subcategory" placeholder="Enter Sub Category" class="form-control" required="" ></td>
                                                                </tr>

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row clearfix">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <center>
                                                        <button type="submit" name="submit" class="btn btn-primary m-t-15 waves-effect">Submit</button></center>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include'footer.php';?>
        <script>
            $(function(){
            $('#addMore').on('click', function() {
                      var data = $("#pd tr:eq(1)").clone(true).appendTo("#pd");
                      data.find("input").val('');
             });
             $(document).on('click', '.remove', function() {
                 var trIndex = $(this).closest("tr").index();
                    if(trIndex>1) {
                     $(this).closest("tr").remove();
                   } else {
                     alert("Sorry!! Can't remove first row!");
                   }
              });
            });      
        </script>


        <?php                            
            if (isset($_POST['submit'])) 
            {                    
                extract($_POST);
                $status=array();
                $total_sub_product=count($_POST['subcategory']);

                for($i=0;$i<$total_sub_product;$i++)
                {
                  if(($_POST['subcategory'][$i]!=""))
                  {

                    $product_subcategory1=$_POST['subcategory'][$i];
                    $product_subcategory=ucwords(strtolower($product_subcategory1));

                     $abc="select * from tbl_subcategory where fld_product_category_id='".$_POST['product_category']."' and fld_subcategory_name = '".$product_subcategory."' ";
                    $nm=mysqli_query($connect,$abc);
                    if(mysqli_num_rows($nm)>0)
                    {
                        echo "<script>";
                        echo "alert('Product Subcategory Is Already Exists');";
                        echo "window.location.href='subcategory_view.php';";
                        echo "</script>";
                    }
                 
                    else
                    {

                      $query = "INSERT INTO tbl_subcategory(fld_product_category_id,fld_subcategory_name ) VALUES ('".$_POST['product_category']."','".$product_subcategory."')" ;
                      $result = mysqli_query($connect,$query)or die(mysqli_error($connect));

                      if(!empty($result)) 
                          {
                             $status[]=1;                   
                          }
                          else
                          {
                              echo "<script>";
                              echo "alert('Sub Category Not Added Successfully');";
                              echo "window.location.href='subcategory_view.php';";
                              echo "</script>";
                          }
                    }
                  }
                } 


                if((isset($status)) &&(in_array('1', $status)))  
                {
                  echo "<script>";
                  echo "alert('Sub Category Added Successfully');";
                  echo "window.location.href='subcategory_view.php';";
                  echo "</script>";
                }                 
            }
        ?>            