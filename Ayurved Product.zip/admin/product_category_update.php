<?php
include "../config.php";
if (isset($_POST['update'])) 
    {
        extract($_POST);

        $product_category1=$_POST['product_category_name'];
        $product_category=ucwords(strtolower($product_category1));
        $coulmn=array();
        $query1=mysqli_query($connect,"select * from tbl_product_category where fld_product_category_name='".$product_category_name."' and  fld_product_category_id!='".$_GET['product_category_id']."' and fld_product_category_delete=0 ");
       
        if (mysqli_num_rows($query1)==1) 
        {
          echo '<script type="text/javascript">'; 
          echo 'alert("Product Category Name Is Already Exist");';
          echo "window.location.href = 'product_category_view.php';";
          echo '</script>'; 

        }    
        else
        {
            $query="Update tbl_product_category set fld_product_category_name='".$product_category_name."' where fld_product_category_id='".$_GET['product_category_id']."' ";
            //echo $query."<br>";
            $row=mysqli_query($connect,$query) or die(mysqli_error($connect));
            if ($row) 
            {
              echo '<script type="text/javascript">';
              echo "alert('Product Category Name Updated');";
              echo 'window.location.href = "product_category_view.php";';
              echo "</script>";

            }
           else
            {
              echo '<script type="text/javascript">';
              echo "alert('Error in Updating Name');";
              echo 'window.location.href = "product_category_view.php";';
              echo "</script>";
               
            }
        }    
    }      

?>
